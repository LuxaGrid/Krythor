---
name: 61-ui-microcopy-kit-nextcue
description: Centralizes UI copy for consistency
---

# NextCue UI Microcopy Kit

Purpose:
Standardize empty, loading, success, error, and toast messages.

Examples:

Empty:
"Nothing here yet."
"Start with your first task."

Loading:
"Loading..."
"Syncing..."

Success:
"All set."
"Saved."

Error:
"That didn’t go through."
"Check connection and try again."
