---
name: 61-ui-microcopy-kit-nextcue
description: Centralized UI microcopy system
---

# NextCue UI Microcopy Kit

Purpose:
Standardize empty, loading, success, error, and toast messages.

Empty:
Nothing here yet.
Start with your first task.

Loading:
Loading...
Syncing...

Success:
All set.
Saved.

Error:
That didn’t go through.
Check connection and try again.
