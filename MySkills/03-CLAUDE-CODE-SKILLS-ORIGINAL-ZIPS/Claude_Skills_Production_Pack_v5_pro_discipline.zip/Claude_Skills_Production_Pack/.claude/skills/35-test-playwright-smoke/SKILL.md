---
name: 35-test-playwright-smoke
description: Install/prepare Playwright and run a smoke test for a route; save artifacts.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Bash, Glob
argument-hint: "[route like /login]"
---


Do:
1) If Playwright not installed, write exact install commands to `TESTING.md`:
   - `npm i -D @playwright/test`
   - `npx playwright install`
2) Ensure `playwright.config.ts` exists (copy from templates).
3) Ensure `tests/smoke.spec.ts` exists (copy from templates and update route usage).
4) Run: `bash scripts/playwright_smoke.sh "$ARGUMENTS"`
5) Ensure artifacts land in `test-artifacts/`.

Rules:
- Keep smoke test simple: load route, basic expectation.

