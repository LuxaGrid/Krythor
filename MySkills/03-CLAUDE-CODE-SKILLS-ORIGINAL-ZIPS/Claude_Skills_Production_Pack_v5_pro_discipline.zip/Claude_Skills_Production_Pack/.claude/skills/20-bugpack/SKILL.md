---
name: 20-bugpack
description: Create a BugPack evidence bundle (.bugpacks/) with check output, npm ls/audit, and env keys.
disable-model-invocation: true
allowed-tools: Bash, Read, Write
argument-hint: "[note]"
---


Run: `bash scripts/bugpack.sh "$ARGUMENTS"`

Rules:
- Never include secret values. Env keys only.
Output:
- BugPack path
- What to paste into Claude Code for fixing

