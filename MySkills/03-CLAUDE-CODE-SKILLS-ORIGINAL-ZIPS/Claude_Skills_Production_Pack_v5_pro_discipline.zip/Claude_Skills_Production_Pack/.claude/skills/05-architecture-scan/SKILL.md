---
name: 05-architecture-scan
description: Generate an architecture report: router detection, structure health, boundary risks, env usage risks.
disable-model-invocation: true
allowed-tools: Bash, Read, Write
argument-hint: ""
---


Run: `bash scripts/architecture_scan.sh`

Then summarize `ARCHITECTURE_REPORT.md` with:
- top 3 risks
- top 3 quick improvements
Keep it practical and minimal.

