---
name: 10-check
description: Run lint + typecheck + build, report ONLY the first real error and how to re-run.
disable-model-invocation: true
allowed-tools: Bash, Read, Write
argument-hint: ""
---


Run `bash scripts/check.sh`.

Then:
1) If it fails: identify the FIRST real error line (not cascades).
2) Report:
   - command that failed
   - file/line
   - likely root cause (brief)
3) Suggest the smallest fix direction (no refactor).

Output format:
- Primary error
- Where it originates
- Rerun command

