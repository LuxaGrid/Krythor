---
name: 20-fixloop
description: BugPack → root cause → smallest patch → verify → log ERROR_PLAYBOOK entry.
disable-model-invocation: true
allowed-tools: Bash, Read, Write, Edit, Grep, Glob
argument-hint: "[what broke]"
---


Process:
1) Run `/20-bugpack $ARGUMENTS`.
2) Read latest `.bugpacks/*/check.txt` and find the FIRST real error.
3) Classify into ONE bucket:
   - Env/config drift
   - Next client/server boundary
   - Firebase Admin misuse
   - Firestore rules/auth
   - Dependency/tooling mismatch
   - Runtime data shape / undefined
4) Apply smallest patch.
5) Re-run: `bash scripts/check.sh`
6) Append to ERROR_PLAYBOOK.md (use `/20-playbook-add` if helpful).

Rules:
- No big refactors.
- Always verify.

