---
name: 40-firebase-hosting-check
description: Sanity check Firebase Hosting config: headers, rewrites, output dir, SPA routing gotchas.
disable-model-invocation: true
allowed-tools: Read, Write, Grep
argument-hint: ""
---


Do:
1) Open firebase.json and check:
   - headers exist
   - rewrites/redirects exist if SPA routing needed
2) Verify docs exist:
   - FIREBASE_HOSTING.md
   - SECURITY_HEADERS.md
3) Output a checklist and highlight risks:
   - missing rewrite for client-side routing
   - overly permissive CSP
   - missing nosniff/referrer policy

No destructive changes unless clearly safe.

