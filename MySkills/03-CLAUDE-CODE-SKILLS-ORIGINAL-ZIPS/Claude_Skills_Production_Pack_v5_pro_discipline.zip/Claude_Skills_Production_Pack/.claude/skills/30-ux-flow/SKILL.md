---
name: 30-ux-flow
description: Create a UX flow spec: screens/routes, states, edge cases, microcopy, analytics events.
disable-model-invocation: true
allowed-tools: Read, Write
argument-hint: "[feature name]"
---


Create `UX_FLOW_<feature>.md` that includes:
- Goal + success definition
- Routes (Pages Router first)
- Data needed
- Loading/Empty/Error states
- Edge cases
- Accessibility notes
- Microcopy suggestions
- Analytics events (event name + properties)

No code changes.

