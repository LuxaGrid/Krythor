---
name: 50-orchestrate-big-task
description: Orchestrate a large task using a safe multi-step loop: Plan → Implement → Test → Review → Document. Includes a punch-list (mini Kanban) so work stays linear.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob, Bash
argument-hint: "[task goal + constraints]"
---

# 50-orchestrate-big-task

This skill is for tasks that are bigger than a quick fix (multi-file changes, new feature, refactor).

## Input
$ARGUMENTS describes the goal, scope, constraints, and “must-haves”.
If $ARGUMENTS is empty, infer the goal from context, but keep scope minimal.

## Guardrails (do not violate)
- Do not run destructive commands (no deleting large folders, no rewriting history).
- Do not expose secrets. Never print env values.
- Prefer the smallest viable patch set.
- Pages Router default if `/pages` exists; support App Router if `/app` dominates.
- Every change must have a verification step.

## Output artifacts this skill creates
- `PLAN.md` (short plan + acceptance criteria)
- `TASKS.md` (punch-list / mini Kanban using markdown checkboxes)
- Optional: `UX_FLOW_<feature>.md` (if UI/UX task)

---

# The Orchestrator Loop (always in this order)

## 1) PLAN
Create or update `PLAN.md` with:

- **Goal** (1–2 lines)
- **Scope**
  - Included
  - Excluded
- **Approach** (bullets)
- **Files to touch** (expected)
- **Acceptance criteria** (clear “done”)
- **Verification commands** (how to prove it)

If this is a UI/UX feature, also create:
- `/30-ux-flow <feature>` (derive feature name from $ARGUMENTS)

### Create the punch-list (mini Kanban)
Create `TASKS.md` with sections like:

## Backlog
- [ ] Task 1
- [ ] Task 2

## In Progress
- [ ] (Move ONE task here at a time)

## Done
- [ ]

Rules:
- Keep tasks small and specific (1–30 minutes each).
- Only ONE item in “In Progress” at any time.
- When a task is finished, check it off and move it to Done.
- If you discover new tasks, add them to Backlog.

At the end of PLAN, list the *first* task you will move to “In Progress”.

---

## 2) IMPLEMENT (one task at a time)
Work strictly from `TASKS.md`:

1) Move the next task to **In Progress**
2) Implement the smallest change to complete it
3) Mark it done and move to **Done**
4) Repeat

Use pack conventions:
- UI primitives: `src/components/ui/`
- Layout: `src/components/layout/AppShell.tsx`
- Env validation: `src/lib/env.ts`
- Firebase Hosting: don’t break existing firebase.json; document uncertainty instead

If scaffolding is missing, run:
- `/00-setup-tailwind-ui` (for primitives/layout)
- `/00-setup-env` (for env)
- `/00-setup-firebase-hosting` (for hosting docs/headers)

---

## 3) TEST (prove it works continuously)
After every meaningful chunk (or every 1–3 tasks), run:

- `/10-check` (or `bash scripts/check.sh`)

If you changed a user-facing route:
- `/35-test-playwright-smoke <route>`

### If anything fails
Immediately run:
- `/20-fixloop "<what broke>"`

Then return to step 3 and re-verify.

---

## 4) REVIEW (catch regressions)
Run:
- `/10-pr-review <files/areas changed>`

Specifically verify:
- No server-only imports in client bundles
- No secrets leaked (env/logs)
- UI includes loading/empty/error states
- Firebase rules changes are least-privilege

---

## 5) DOCUMENT (make it repeatable)
Update docs so you don’t redo the work later:

- Bug fix: `/20-playbook-add "<short title>"`
- Feature: update `WORKFLOW.md` if workflow changed
- Hosting: update `FIREBASE_HOSTING.md`
- Headers: update `SECURITY_HEADERS.md`

---

## Final output format (always print)
- Summary of what changed
- Files changed
- Commands run + results
- What’s now in Done vs remaining Backlog
- Remaining TODOs (if any)
