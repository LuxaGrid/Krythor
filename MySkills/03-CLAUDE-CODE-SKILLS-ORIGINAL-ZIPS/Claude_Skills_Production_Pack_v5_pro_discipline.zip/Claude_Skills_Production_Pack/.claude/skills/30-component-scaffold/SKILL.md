---
name: 30-component-scaffold
description: Scaffold a new Tailwind UI component with accessibility defaults and example usage.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob
argument-hint: "[ComponentName]"
---


Create:
- `src/components/ui/<ComponentName>.tsx`
- an example usage snippet in `src/pages/_examples.tsx` or `src/app/_examples/page.tsx` if present

Requirements:
- keyboard + focus-visible support
- clean props
- no hard-coded app-specific logic

