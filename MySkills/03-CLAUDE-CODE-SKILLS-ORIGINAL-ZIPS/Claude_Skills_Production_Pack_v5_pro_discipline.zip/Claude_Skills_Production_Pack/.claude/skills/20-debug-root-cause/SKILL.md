---
name: 20-debug-root-cause
description: Systematic debugging: evidence → first error → classify → hypothesis → smallest fix → verify → document.
disable-model-invocation: true
allowed-tools: Bash, Read, Write, Edit, Grep, Glob
argument-hint: "[what broke + expected vs actual]"
---


This is the “stop guessing” debugger.

1) Evidence
- Run `/20-bugpack $ARGUMENTS`
- Open the latest `.bugpacks/*/check.txt` and identify the **first real error**.

2) Classify (pick ONE)
- Env/config drift
- Next client/server boundary
- Firebase Admin misuse
- Firestore rules/auth
- Dependency/tooling mismatch
- Runtime data shape (undefined/null)

3) Hypothesis
Write 2–4 lines in `DEBUG_NOTES.md`:
- Primary error
- Hypothesis (why)
- Smallest fix idea
- Verify command

4) Apply smallest patch
- Fix only the root cause.
- Avoid refactors.

5) Verify
- Run `/10-check` (or `bash scripts/check.sh`)
- If UI route impacted: `/35-test-playwright-smoke <route>`

6) Document
- Append to ERROR_PLAYBOOK.md (or use `/20-playbook-add "<title>"`)

If anything becomes messy: switch to `/20-fixloop` and then return here.

