---
name: 10-deps-healthcheck
description: Detect dependency/tooling drift that causes repeat bugs: lockfile, npm audit, duplicates.
disable-model-invocation: true
allowed-tools: Bash, Read, Write
argument-hint: ""
---


Run `bash scripts/deps_healthcheck.sh`.

Then:
1) Summarize any high-risk findings:
   - missing lockfile
   - moderate+ vulns
   - duplicate react/next/firebase versions
2) Recommend the minimum safe remediation steps.

Rules:
- Don’t auto-upgrade everything.
- Prefer targeted upgrades for vulnerable packages.

