---
name: 30-a11y-sweep
description: Quick accessibility sweep: labels, semantics, keyboard navigation, focus, aria, motion preferences.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob
argument-hint: "[path-or-route]"
---


Scan target area and fix obvious issues:
- missing <label htmlFor>
- incorrect button/link semantics
- focus ring missing
- aria misuse

Output:
- `A11Y_REPORT.md` with changes and remaining issues.

