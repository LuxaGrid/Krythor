---
name: 48-finish-branch
description: Ship gate: check → smoke (if configured) → hosting sanity → rules guard → perf pass → two-stage review → RELEASE_REPORT.md.
disable-model-invocation: true
allowed-tools: Bash, Read, Write
argument-hint: "[preview|prod]"
---


Run: `bash scripts/finish_branch.sh ${ARGUMENTS:-prod}`

This produces:
- REVIEW_REPORT.md
- RELEASE_REPORT.md
- FIREBASE_RULES_REPORT.md (if rules exist)
- PERFORMANCE_REPORT.md

If anything fails:
- Run `/20-debug-root-cause "<what broke>"` (or `/20-fixloop`) and re-run finish-branch.

