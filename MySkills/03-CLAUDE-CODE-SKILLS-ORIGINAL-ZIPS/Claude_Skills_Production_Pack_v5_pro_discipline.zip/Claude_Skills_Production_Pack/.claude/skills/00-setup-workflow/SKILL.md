---
name: 00-setup-workflow
description: Install repeatable workflow: check scripts, optional pre-commit hook, and Definition of Done.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob, Bash
argument-hint: ""
---


Goal: Make every repo behave the same way so bugs don’t repeat.

Do:
1) Ensure `scripts/check.sh`, `scripts/bugpack.sh`, `scripts/fixloop.sh` exist (copy from this pack if missing).
2) Add `DEFINITION_OF_DONE.md` to repo root if missing (copy template).
3) Add recommended `package.json` scripts if package.json exists:
   - check, bugpack, fixloop, deps:health
4) Optional: add a pre-commit hook (ONLY fast checks):
   - run lint + typecheck (skip build)
   Create `.githooks/pre-commit` and document `git config core.hooksPath .githooks`.
5) Write/update `WORKFLOW.md` with the daily loop and release loop.

Output:
- What you changed and how to use it.

