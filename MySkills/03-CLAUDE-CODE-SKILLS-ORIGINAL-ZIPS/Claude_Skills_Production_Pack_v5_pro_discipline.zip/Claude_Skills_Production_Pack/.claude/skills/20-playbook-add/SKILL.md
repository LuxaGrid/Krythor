---
name: 20-playbook-add
description: Append a clean, standardized entry to ERROR_PLAYBOOK.md for the latest fix.
disable-model-invocation: true
allowed-tools: Read, Write, Edit
argument-hint: "[short title]"
---


Append an entry using the template in ERROR_PLAYBOOK.md.

Include:
- Symptom (exact error text)
- Root cause (why)
- Fix (files changed)
- Verify command
- Prevention (test/guard/doc)

