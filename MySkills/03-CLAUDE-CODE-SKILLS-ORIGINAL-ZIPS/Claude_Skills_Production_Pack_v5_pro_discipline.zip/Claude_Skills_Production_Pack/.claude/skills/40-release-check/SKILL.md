---
name: 40-release-check
description: Pre-deploy checklist: check gate, hosting sanity, headers, env, smoke test.
disable-model-invocation: true
allowed-tools: Bash, Read, Write
argument-hint: "[preview|prod]"
---


Run:
1) `bash scripts/check.sh`
2) `/40-firebase-hosting-check`
3) If Playwright configured: `bash scripts/playwright_smoke.sh "/"` (or your main route)
4) Summarize findings in `RELEASE_REPORT.md`:
   - target (preview/prod)
   - commands run + results
   - blockers and fixes

Rules:
- Prefer quick confidence over perfection.

