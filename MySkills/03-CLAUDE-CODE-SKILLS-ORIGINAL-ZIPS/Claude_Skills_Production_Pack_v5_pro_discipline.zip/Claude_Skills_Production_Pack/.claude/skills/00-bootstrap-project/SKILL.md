---
name: 00-bootstrap-project
description: One-command conservative bootstrap: detects router, ensures folders, prints exact install steps, and prepares templates.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob, Bash
argument-hint: ""
---


Run: `bash scripts/bootstrap_project.sh`

Then:
1) If Tailwind missing, follow printed install steps.
2) Copy templates into place (as needed):
   - templates/env.ts -> src/lib/env.ts
   - templates/env.example -> env.example
   - templates/layout_AppShell.tsx -> src/components/layout/AppShell.tsx
   - templates/ui_*.tsx -> src/components/ui/
   - templates/playwright.config.ts -> playwright.config.ts
   - templates/tests_smoke.spec.ts -> tests/smoke.spec.ts
3) Update package.json scripts (printed by bootstrap).

Rules:
- Be conservative: do not overwrite existing files unless user requests.
Output:
- What was detected and what’s left to do.

