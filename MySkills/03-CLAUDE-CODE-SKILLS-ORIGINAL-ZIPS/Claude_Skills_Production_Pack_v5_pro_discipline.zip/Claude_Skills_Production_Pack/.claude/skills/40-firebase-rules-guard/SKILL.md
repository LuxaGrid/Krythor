---
name: 40-firebase-rules-guard
description: Scan Firestore rules for dangerous patterns (allow if true, catch-all rules). Writes FIREBASE_RULES_REPORT.md.
disable-model-invocation: true
allowed-tools: Bash, Read, Write
argument-hint: "[optional path hint]"
---


Run: `bash scripts/firebase_rules_guard.sh`

If rules file is not at repo root, use $ARGUMENTS as a hint and update the script/report accordingly.

Then summarize FIREBASE_RULES_REPORT.md and recommend least-privilege fixes (do not widen permissions).

