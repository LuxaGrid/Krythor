---
name: 30-ui-build-pages
description: Build Pages Router UI for a feature using Tailwind primitives and proper states.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob
argument-hint: "[feature/route]"
---


Build:
- `/pages/<route>.tsx` (or nested)
- `src/components/<feature>/...`

Use primitives from `src/components/ui/`:
- Button, Input, Card, Skeleton, EmptyState

Include:
- Loading skeleton
- Empty state with CTA
- Error state with actionable message (+ Retry if applicable)

Rules:
- No firebase-admin in client.
- No secrets in client.
- Keep readable for a new dev.

