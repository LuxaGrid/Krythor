---
name: 40-security-audit-quick
description: Quick security pass for Next.js + Firebase: secrets, boundaries, rules hazards, headers, logging hygiene.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob, Bash
argument-hint: ""
---


Check:
- secrets in repo / logs
- server-only imports in client (firebase-admin, fs, etc.)
- firestore rules red flags
- headers presence in firebase.json
- npm audit moderate+

Write `SECURITY_REPORT.md` with:
- P0/P1/P2 items
- evidence (file paths)
- minimal fixes (apply P0/P1 when obvious)

Rules:
- Don’t widen rules without need.
- Don’t expose secrets.

