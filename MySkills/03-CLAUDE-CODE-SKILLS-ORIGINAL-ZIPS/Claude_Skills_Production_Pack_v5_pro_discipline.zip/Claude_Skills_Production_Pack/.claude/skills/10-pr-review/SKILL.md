---
name: 10-pr-review
description: Review changes for Next.js + Firebase: client/server boundaries, env safety, rules alignment, and regression risks.
disable-model-invocation: true
allowed-tools: Read, Grep, Glob
argument-hint: "[files or areas]"
---


Checklist:
- Client/server boundary: no firebase-admin or node-only modules in client components
- Env: NEXT_PUBLIC usage correct, no secrets leaked
- Firebase rules: least privilege; no `allow read, write: if true`
- UI: has loading/empty/error states for data screens
- Tests: smoke test updated if relevant

Output:
✅ Safe / ⚠️ Needs attention / ❌ Blockers

