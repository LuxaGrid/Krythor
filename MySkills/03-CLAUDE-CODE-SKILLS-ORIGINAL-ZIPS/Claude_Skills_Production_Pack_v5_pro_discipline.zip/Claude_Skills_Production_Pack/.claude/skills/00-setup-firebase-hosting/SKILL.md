---
name: 00-setup-firebase-hosting
description: Firebase Hosting baseline: headers snippet, routing notes, deploy docs (Pages-first).
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob
argument-hint: "[pages|app|both] (default: pages)"
---


Do:
1) Detect router style:
   - Pages if `/pages` exists
   - App if `/app` exists
2) Ensure `firebase.json` exists. If missing, create a minimal safe skeleton and a TODO to fill build output.
3) Add basic security headers to firebase.json using templates/firebase_headers_snippet.json (document CSP caveats).
4) Write `FIREBASE_HOSTING.md`:
   - build command
   - output directory
   - deploy command
   - SPA routing notes (rewrites) and common pitfalls
5) Add `SECURITY_HEADERS.md` explaining how to extend CSP for Firebase Auth, fonts, analytics.

Rules:
- Don’t break existing deploy configs; if uncertain, document instead of changing output folders.

