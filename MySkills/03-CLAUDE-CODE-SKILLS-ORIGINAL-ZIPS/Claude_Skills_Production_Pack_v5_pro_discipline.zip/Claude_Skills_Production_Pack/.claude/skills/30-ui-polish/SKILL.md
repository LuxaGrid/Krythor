---
name: 30-ui-polish
description: Make UI look intentional: spacing, typography, hierarchy, micro-interactions, and consistency (Tailwind-only).
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob
argument-hint: "[page/component path]"
---


Use principles from `.claude/references/frontend_design.md`.

Do:
1) Identify current visual issues:
   - hierarchy, spacing rhythm, clutter, inconsistent font sizes, weak CTAs
2) Apply improvements:
   - consistent section spacing
   - better type scale (H1/H2/body/muted)
   - stronger card layout and page framing
   - subtle hover/focus states
3) Ensure accessibility:
   - focus-visible
   - label/input pairing
4) Write a short `UI_POLISH_NOTES.md` entry describing the direction.

Rules:
- Tailwind-only.
- Don’t redesign everything—improve the existing screen.

