---
name: 50-orchestrate-resume
description: Resume an existing orchestrated task by reading TASKS.md and continuing one checkbox at a time with the same safe loop.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob, Bash
argument-hint: "[optional note]"
---


Do:
1) Read `PLAN.md` and `TASKS.md`.
2) If there is anything in **In Progress**:
   - Continue that item first.
3) Otherwise, move the next unchecked item from **Backlog** to **In Progress** (one item only).
4) Implement the smallest change to complete it.
5) After 1–3 tasks, run `/10-check`.
6) If UI route impacted, run `/35-test-playwright-smoke <route>` (best effort).
7) When a bug is fixed, append to ERROR_PLAYBOOK.md.

Rules:
- Keep scope tight: follow TASKS.md, don’t invent a new plan.
- If something breaks, run `/20-fixloop "<what broke>"` then resume.
Output:
- Which task was resumed
- What changed
- What’s now Done vs remaining Backlog

