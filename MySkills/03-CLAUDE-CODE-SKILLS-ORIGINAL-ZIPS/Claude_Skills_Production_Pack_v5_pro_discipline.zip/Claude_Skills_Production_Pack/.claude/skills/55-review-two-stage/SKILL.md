---
name: 55-review-two-stage
description: Two-stage review: Spec compliance (PLAN/TASKS) then code quality (boundaries, env, rules, UI states). Writes REVIEW_REPORT.md.
disable-model-invocation: true
allowed-tools: Bash, Read, Write, Grep, Glob
argument-hint: "[optional changed areas]"
---


Run: `bash scripts/review_two_stage.sh`

Then perform the review with two passes:

## Pass 1 — Spec Compliance
- Compare against PLAN.md and TASKS.md (if present)
- Validate acceptance criteria
- Confirm no scope creep

## Pass 2 — Code Quality
- Client/server boundary (no firebase-admin in UI)
- Env safety (NEXT_PUBLIC only in client)
- Firebase rules least-privilege
- Tailwind consistency (use primitives)
- Error handling (actionable)

Update REVIEW_REPORT.md with findings:
✅ Safe / ⚠️ Needs attention / ❌ Blockers

If blockers exist, create tasks in TASKS.md.

