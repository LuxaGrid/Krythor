---
name: 00-setup-env
description: Create env.example + strict env validator; prevent server secrets leaking into client.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob
argument-hint: "[firebase|next|all] (default: all)"
---


Do:
1) Scan for env usage:
   - `process.env.*`
   - `NEXT_PUBLIC_*`
2) Create/update `env.example` (keys only, no values).
3) Create `src/lib/env.ts` using templates/env.ts.
4) Ensure client code uses only NEXT_PUBLIC_* variables.
5) Add a short `ENV.md` explaining:
   - where to set env locally (dotenv)
   - how Firebase Hosting env works for your deployment approach

Rules:
- Never write actual secrets.
- Never move server-only secrets into NEXT_PUBLIC_*.

Output:
- list of required keys + where used
- any unsafe usages found and fixed

