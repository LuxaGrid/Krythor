---
name: 45-performance-pass
description: Quick performance pass: bundle boundary checks, public asset size hints, raw <img> detection. Writes PERFORMANCE_REPORT.md.
disable-model-invocation: true
allowed-tools: Bash, Read, Write
argument-hint: ""
---


Run: `bash scripts/performance_pass.sh`

Then summarize PERFORMANCE_REPORT.md with:
- biggest likely wins
- quick next steps

