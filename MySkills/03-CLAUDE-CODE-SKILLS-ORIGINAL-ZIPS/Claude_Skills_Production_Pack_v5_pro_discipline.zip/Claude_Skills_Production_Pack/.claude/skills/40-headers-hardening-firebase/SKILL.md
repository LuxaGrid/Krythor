---
name: 40-headers-hardening-firebase
description: Apply safe security headers via firebase.json + document CSP extension strategy.
disable-model-invocation: true
allowed-tools: Read, Write, Edit
argument-hint: ""
---


1) Merge templates/firebase_headers_snippet.json into firebase.json headers (don’t duplicate).
2) Create/update SECURITY_HEADERS.md:
   - what each header does
   - how to test in browser
   - how to extend CSP for Firebase Auth / fonts / analytics

Rules:
- Keep CSP conservative but practical.
- Don’t add HSTS unless you confirm HTTPS-only.

