---
name: 00-setup-tailwind-ui
description: Tailwind-first UI foundation: tokens + primitives + layout so you build screens fast.
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob, Bash
argument-hint: ""
---


Do:
1) Detect Tailwind:
   - tailwind config exists OR globals has `@tailwind base; @tailwind components; @tailwind utilities;`
2) If missing, write `TAILWIND_SETUP.md` with the exact install commands (don’t guess versions).
3) Create `src/components/ui/` primitives by copying templates:
   - Button, Input, Card, Skeleton, EmptyState
4) Create `src/components/layout/AppShell.tsx` (simple header/container/footer).
5) Ensure focus-visible rings exist on interactive elements.
6) Add `DESIGN_SYSTEM.md` (or update) with usage examples.

Output:
- files created/updated and how to import them

